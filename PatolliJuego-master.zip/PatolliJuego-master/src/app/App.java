package app;

import GUI.InicioJF;

public class App {

    public static void main(String[] args) {
        InicioJF v = new InicioJF();
        v.setVisible(true);
    }
    
}
